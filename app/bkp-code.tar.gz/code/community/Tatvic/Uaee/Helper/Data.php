<?php
/**
 * @package
 * @author (khushboo@tatvic.com)
 * @license Tatvic Enhanced Ecommerce
 */ 
class Tatvic_Uaee_Helper_Data extends Mage_Core_Helper_Abstract {
	
}